let a = prompt("nhap a:");
let so1 = Number (a);

let b =prompt ("nhap b");
 let so2= Number(b);
 let  c = so1;

  so1 = so2 ;

  so2 = c;

alert (" sau khi swap " +"\n" +
  "a= " + so1 + "\n" +
  "b=" + so2
 );

 










