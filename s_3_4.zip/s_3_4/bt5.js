let total = 0;

for( let i=0 ; i<=50; i++)
{
    total += i;
}

alert(`tong 50 so dau tien ${total}`);
