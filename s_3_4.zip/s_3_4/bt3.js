const a = Number(prompt("nhap so a: "));
const b = Number(prompt("nhap so b: "));

const c= -b/a;
alert (`voi bieu thu ${a}x+${b}=0 ta tim duoc x=${c}`);
